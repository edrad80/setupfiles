#!/usr/bin/env python3
"""
Standalone test script for the comprehensive analyzer
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from src.analysis.comprehensive_analyzer import ComprehensiveAnalyzer
import json

def test_analyzer():
    """Test the comprehensive analyzer with a simple website"""
    print("Testing Comprehensive AI Optimization Analyzer...")
    print("=" * 50)
    
    # Initialize analyzer
    analyzer = ComprehensiveAnalyzer()
    
    # Test with example.com
    test_url = "https://example.com"
    print(f"Analyzing: {test_url}")
    
    try:
        # Perform analysis
        result = analyzer.analyze_website(test_url)
        
        if result['success']:
            print("\n✅ Analysis completed successfully!")
            print(f"Master Score: {result['scores']['master_score']}/100")
            print(f"Citation Probability: {result['scores']['citation_probability']}%")
            
            print("\nComponent Scores:")
            print(f"  SEO Foundation: {result['scores']['seo_score']}/100")
            print(f"  AIO Optimization: {result['scores']['aio_score']}/100") 
            print(f"  GEO Trust Signals: {result['scores']['geo_score']}/100")
            print(f"  AEO Answer Format: {result['scores']['aeo_score']}/100")
            
            print(f"\nTop Recommendations ({len(result['recommendations'])}):")
            for i, rec in enumerate(result['recommendations'][:5], 1):
                print(f"  {i}. [{rec['priority']}] {rec['title']}")
                print(f"     {rec['description']}")
            
            print(f"\nContent Metrics:")
            metrics = result.get('content_metrics', {})
            print(f"  Word Count: {metrics.get('word_count', 'N/A')}")
            print(f"  Headings: {metrics.get('heading_count', 'N/A')}")
            print(f"  Images: {metrics.get('image_count', 'N/A')}")
            
            # Save detailed results
            with open('/tmp/analyzer_test_result.json', 'w') as f:
                json.dump(result, f, indent=2)
            print(f"\nDetailed results saved to: /tmp/analyzer_test_result.json")
            
        else:
            print(f"❌ Analysis failed: {result.get('error', 'Unknown error')}")
            
    except Exception as e:
        print(f"❌ Test failed with exception: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_analyzer()

