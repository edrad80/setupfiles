from src.models.user import db
from datetime import datetime
import json

class Scan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    url = db.Column(db.String(500), nullable=False)
    user_email = db.Column(db.String(120), nullable=True)  # Optional for free scans
    scan_date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='pending')  # pending, completed, failed
    score = db.Column(db.Integer, nullable=True)  # Overall AI optimization score
    citation_probability = db.Column(db.Float, nullable=True)  # AI citation probability
    pagespeed_data = db.Column(db.Text, nullable=True)  # JSON data from PageSpeed Insights
    ai_analysis = db.Column(db.Text, nullable=True)  # JSON data from AI analysis (legacy)
    enhanced_analysis = db.Column(db.Text, nullable=True)  # JSON data from comprehensive analysis
    recommendations = db.Column(db.Text, nullable=True)  # JSON array of recommendations
    report_html = db.Column(db.Text, nullable=True)  # Generated HTML report
    report_pdf_path = db.Column(db.String(500), nullable=True)  # Path to PDF file
    error_message = db.Column(db.Text, nullable=True)  # Error message if scan failed

    def __repr__(self):
        return f'<Scan {self.url}>'

    def to_dict(self):
        return {
            'id': self.id,
            'url': self.url,
            'user_email': self.user_email,
            'scan_date': self.scan_date.isoformat() if self.scan_date else None,
            'status': self.status,
            'score': self.score,
            'citation_probability': self.citation_probability,
            'pagespeed_data': json.loads(self.pagespeed_data) if self.pagespeed_data else None,
            'ai_analysis': json.loads(self.ai_analysis) if self.ai_analysis else None,
            'enhanced_analysis': json.loads(self.enhanced_analysis) if self.enhanced_analysis else None,
            'recommendations': json.loads(self.recommendations) if self.recommendations else None,
            'report_html': self.report_html,
            'report_pdf_path': self.report_pdf_path,
            'error_message': self.error_message
        }

    def set_pagespeed_data(self, data):
        self.pagespeed_data = json.dumps(data)

    def set_ai_analysis(self, data):
        self.ai_analysis = json.dumps(data)

    def set_enhanced_analysis(self, data):
        self.enhanced_analysis = json.dumps(data)

    def set_recommendations(self, data):
        self.recommendations = json.dumps(data)


class Subscription(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_email = db.Column(db.String(120), unique=True, nullable=False)
    stripe_customer_id = db.Column(db.String(100), nullable=True)
    stripe_subscription_id = db.Column(db.String(100), nullable=True)
    plan_type = db.Column(db.String(20), nullable=False)  # free, single, monthly
    status = db.Column(db.String(20), default='active')  # active, cancelled, expired
    scans_used = db.Column(db.Integer, default=0)
    scans_limit = db.Column(db.Integer, default=1)  # 1 for free, -1 for unlimited
    created_date = db.Column(db.DateTime, default=datetime.utcnow)
    expires_date = db.Column(db.DateTime, nullable=True)

    def __repr__(self):
        return f'<Subscription {self.user_email}>'

    def to_dict(self):
        return {
            'id': self.id,
            'user_email': self.user_email,
            'plan_type': self.plan_type,
            'status': self.status,
            'scans_used': self.scans_used,
            'scans_limit': self.scans_limit,
            'created_date': self.created_date.isoformat() if self.created_date else None,
            'expires_date': self.expires_date.isoformat() if self.expires_date else None
        }

    def can_scan(self):
        if self.status != 'active':
            return False
        if self.scans_limit == -1:  # Unlimited
            return True
        return self.scans_used < self.scans_limit

    def increment_scan_count(self):
        self.scans_used += 1

