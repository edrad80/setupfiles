from flask import Blueprint, jsonify, request, render_template_string, make_response
from src.models.scan import Scan, db
import os
from datetime import datetime
import json

report_bp = Blueprint('report', __name__)

# HTML template for the report
HTML_REPORT_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Optimization Report - {{ scan.url }}</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background: #f8f9fa;
        }
        .report-container {
            background: white;
            border-radius: 12px;
            padding: 40px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .header {
            text-align: center;
            border-bottom: 3px solid #4f46e5;
            padding-bottom: 30px;
            margin-bottom: 40px;
        }
        .logo {
            font-size: 24px;
            font-weight: bold;
            color: #4f46e5;
            margin-bottom: 10px;
        }
        .scan-url {
            font-size: 18px;
            color: #666;
            word-break: break-all;
        }
        .score-section {
            text-align: center;
            margin: 40px 0;
            padding: 30px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 12px;
            color: white;
        }
        .score-circle {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 36px;
            font-weight: bold;
        }
        .score-label {
            font-size: 18px;
            opacity: 0.9;
        }
        .analysis-section {
            margin: 40px 0;
        }
        .section-title {
            font-size: 24px;
            font-weight: bold;
            color: #1f2937;
            margin-bottom: 20px;
            border-left: 4px solid #4f46e5;
            padding-left: 16px;
        }
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        .metric-card {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid #10b981;
        }
        .metric-card.warning {
            border-left-color: #f59e0b;
        }
        .metric-card.error {
            border-left-color: #ef4444;
        }
        .metric-title {
            font-weight: bold;
            margin-bottom: 8px;
        }
        .metric-value {
            font-size: 24px;
            font-weight: bold;
            color: #10b981;
        }
        .metric-value.warning {
            color: #f59e0b;
        }
        .metric-value.error {
            color: #ef4444;
        }
        .recommendations {
            margin: 40px 0;
        }
        .recommendation {
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 16px;
        }
        .recommendation.critical {
            border-left: 4px solid #ef4444;
        }
        .recommendation.high {
            border-left: 4px solid #f59e0b;
        }
        .recommendation.medium {
            border-left: 4px solid #3b82f6;
        }
        .rec-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }
        .rec-title {
            font-weight: bold;
            font-size: 16px;
        }
        .rec-priority {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }
        .priority-critical {
            background: #fee2e2;
            color: #dc2626;
        }
        .priority-high {
            background: #fef3c7;
            color: #d97706;
        }
        .priority-medium {
            background: #dbeafe;
            color: #2563eb;
        }
        .rec-category {
            color: #6b7280;
            font-size: 14px;
            margin-bottom: 8px;
        }
        .rec-description {
            color: #4b5563;
            line-height: 1.6;
        }
        .footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #e5e7eb;
            color: #6b7280;
            font-size: 14px;
        }
        .scan-date {
            color: #6b7280;
            font-size: 14px;
        }
        @media print {
            body { background: white; }
            .report-container { box-shadow: none; }
        }
    </style>
</head>
<body>
    <div class="report-container">
        <div class="header">
            <div class="logo">🤖 AI Optimizer</div>
            <h1>Website AI Optimization Report</h1>
            <div class="scan-url">{{ scan.url }}</div>
            <div class="scan-date">Generated on {{ scan.scan_date.strftime('%B %d, %Y at %I:%M %p') }}</div>
        </div>

        <div class="score-section">
            <div class="score-circle">{{ scan.score }}/100</div>
            <div class="score-label">AI Optimization Score</div>
        </div>

        <div class="analysis-section">
            <h2 class="section-title">Performance Metrics</h2>
            <div class="metrics-grid">
                <div class="metric-card {% if analysis.performance_score >= 90 %}{% elif analysis.performance_score >= 70 %}warning{% else %}error{% endif %}">
                    <div class="metric-title">Performance</div>
                    <div class="metric-value {% if analysis.performance_score >= 90 %}{% elif analysis.performance_score >= 70 %}warning{% else %}error{% endif %}">{{ analysis.performance_score }}/100</div>
                </div>
                <div class="metric-card {% if analysis.accessibility_score >= 90 %}{% elif analysis.accessibility_score >= 70 %}warning{% else %}error{% endif %}">
                    <div class="metric-title">Accessibility</div>
                    <div class="metric-value {% if analysis.accessibility_score >= 90 %}{% elif analysis.accessibility_score >= 70 %}warning{% else %}error{% endif %}">{{ analysis.accessibility_score }}/100</div>
                </div>
                <div class="metric-card {% if analysis.best_practices_score >= 90 %}{% elif analysis.best_practices_score >= 70 %}warning{% else %}error{% endif %}">
                    <div class="metric-title">Best Practices</div>
                    <div class="metric-value {% if analysis.best_practices_score >= 90 %}{% elif analysis.best_practices_score >= 70 %}warning{% else %}error{% endif %}">{{ analysis.best_practices_score }}/100</div>
                </div>
                <div class="metric-card {% if analysis.seo_score >= 90 %}{% elif analysis.seo_score >= 70 %}warning{% else %}error{% endif %}">
                    <div class="metric-title">SEO</div>
                    <div class="metric-value {% if analysis.seo_score >= 90 %}{% elif analysis.seo_score >= 70 %}warning{% else %}error{% endif %}">{{ analysis.seo_score }}/100</div>
                </div>
            </div>
        </div>

        <div class="analysis-section">
            <h2 class="section-title">AI Optimization Factors</h2>
            <div class="metrics-grid">
                <div class="metric-card {% if analysis.structured_data_present %}{% else %}error{% endif %}">
                    <div class="metric-title">Structured Data</div>
                    <div class="metric-value {% if analysis.structured_data_present %}{% else %}error{% endif %}">
                        {% if analysis.structured_data_present %}✓ Present{% else %}✗ Missing{% endif %}
                    </div>
                </div>
                <div class="metric-card {% if analysis.meta_description_present %}{% else %}warning{% endif %}">
                    <div class="metric-title">Meta Description</div>
                    <div class="metric-value {% if analysis.meta_description_present %}{% else %}warning{% endif %}">
                        {% if analysis.meta_description_present %}✓ Present{% else %}✗ Missing{% endif %}
                    </div>
                </div>
                <div class="metric-card {% if analysis.mobile_friendly %}{% else %}error{% endif %}">
                    <div class="metric-title">Mobile Friendly</div>
                    <div class="metric-value {% if analysis.mobile_friendly %}{% else %}error{% endif %}">
                        {% if analysis.mobile_friendly %}✓ Yes{% else %}✗ No{% endif %}
                    </div>
                </div>
                <div class="metric-card {% if analysis.core_web_vitals_good %}{% else %}warning{% endif %}">
                    <div class="metric-title">Core Web Vitals</div>
                    <div class="metric-value {% if analysis.core_web_vitals_good %}{% else %}warning{% endif %}">
                        {% if analysis.core_web_vitals_good %}✓ Good{% else %}⚠ Needs Work{% endif %}
                    </div>
                </div>
            </div>
        </div>

        <div class="recommendations">
            <h2 class="section-title">Recommendations</h2>
            {% for rec in recommendations %}
            <div class="recommendation {{ rec.priority.lower() }}">
                <div class="rec-header">
                    <div class="rec-title">{{ rec.title }}</div>
                    <div class="rec-priority priority-{{ rec.priority.lower() }}">{{ rec.priority }}</div>
                </div>
                <div class="rec-category">{{ rec.category }} • Impact: {{ rec.impact }}</div>
                <div class="rec-description">{{ rec.description }}</div>
            </div>
            {% endfor %}
        </div>

        <div class="footer">
            <p>This report was generated by AI Optimizer - Website AI Optimization Testing & Reporting</p>
            <p>For more information, visit our website or contact support.</p>
        </div>
    </div>
</body>
</html>
"""

@report_bp.route('/report/<int:scan_id>', methods=['GET'])
def get_html_report(scan_id):
    """Generate HTML report for a scan"""
    try:
        scan = Scan.query.get_or_404(scan_id)
        
        if scan.status != 'completed':
            return jsonify({'error': 'Scan not completed yet'}), 400
        
        # Parse the JSON data
        analysis = json.loads(scan.ai_analysis) if scan.ai_analysis else {}
        recommendations = json.loads(scan.recommendations) if scan.recommendations else []
        
        # Generate HTML report
        html_content = render_template_string(
            HTML_REPORT_TEMPLATE,
            scan=scan,
            analysis=analysis,
            recommendations=recommendations
        )
        
        # Save HTML report to scan record
        scan.report_html = html_content
        db.session.commit()
        
        return html_content
        
    except Exception as e:
        print(f"Report generation error: {e}")
        return jsonify({'error': 'Failed to generate report'}), 500

@report_bp.route('/report/<int:scan_id>/pdf', methods=['GET'])
def get_pdf_report(scan_id):
    """Generate PDF report for a scan"""
    try:
        scan = Scan.query.get_or_404(scan_id)
        
        if scan.status != 'completed':
            return jsonify({'error': 'Scan not completed yet'}), 400
        
        # First generate HTML if not exists
        if not scan.report_html:
            analysis = json.loads(scan.ai_analysis) if scan.ai_analysis else {}
            recommendations = json.loads(scan.recommendations) if scan.recommendations else []
            
            html_content = render_template_string(
                HTML_REPORT_TEMPLATE,
                scan=scan,
                analysis=analysis,
                recommendations=recommendations
            )
            scan.report_html = html_content
            db.session.commit()
        
        # For now, return the HTML content with PDF headers
        # In production, you would use a library like weasyprint to convert HTML to PDF
        response = make_response(scan.report_html)
        response.headers['Content-Type'] = 'text/html'
        response.headers['Content-Disposition'] = f'attachment; filename="ai-optimization-report-{scan_id}.html"'
        
        return response
        
    except Exception as e:
        print(f"PDF generation error: {e}")
        return jsonify({'error': 'Failed to generate PDF'}), 500

@report_bp.route('/report/<int:scan_id>/download', methods=['GET'])
def download_report(scan_id):
    """Download report as HTML file"""
    try:
        scan = Scan.query.get_or_404(scan_id)
        
        if scan.status != 'completed':
            return jsonify({'error': 'Scan not completed yet'}), 400
        
        # Generate HTML if not exists
        if not scan.report_html:
            analysis = json.loads(scan.ai_analysis) if scan.ai_analysis else {}
            recommendations = json.loads(scan.recommendations) if scan.recommendations else []
            
            html_content = render_template_string(
                HTML_REPORT_TEMPLATE,
                scan=scan,
                analysis=analysis,
                recommendations=recommendations
            )
            scan.report_html = html_content
            db.session.commit()
        
        # Return HTML file for download
        response = make_response(scan.report_html)
        response.headers['Content-Type'] = 'text/html'
        response.headers['Content-Disposition'] = f'attachment; filename="ai-optimization-report-{scan.url.replace("https://", "").replace("http://", "").replace("/", "-")}.html"'
        
        return response
        
    except Exception as e:
        print(f"Download error: {e}")
        return jsonify({'error': 'Failed to download report'}), 500

