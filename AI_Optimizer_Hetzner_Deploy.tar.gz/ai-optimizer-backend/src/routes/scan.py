from flask import Blueprint, request, jsonify
from src.models.scan import Scan, Subscription, db
from src.analysis.comprehensive_analyzer import ComprehensiveAnalyzer
import requests
import json
import re
from urllib.parse import urlparse
from datetime import datetime, timedelta
import os

scan_bp = Blueprint('scan', __name__)

@scan_bp.route('/test', methods=['GET'])
def test_endpoint():
    """Simple test endpoint"""
    return jsonify({'message': 'Backend is working!', 'status': 'success'})

# You'll need to get a free API key from Google Cloud Console
PAGESPEED_API_KEY = os.environ.get('PAGESPEED_API_KEY', 'YOUR_API_KEY_HERE')
PAGESPEED_API_URL = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed'

def validate_url(url):
    """Validate and normalize URL"""
    if not url:
        return None
    
    # Add protocol if missing
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url
    
    # Basic URL validation
    try:
        result = urlparse(url)
        if not all([result.scheme, result.netloc]):
            return None
        return url
    except:
        return None

def analyze_pagespeed_data(pagespeed_data):
    """Analyze PageSpeed Insights data for AI optimization factors"""
    analysis = {
        'performance_score': 0,
        'accessibility_score': 0,
        'best_practices_score': 0,
        'seo_score': 0,
        'structured_data_present': False,
        'meta_description_present': False,
        'heading_structure_good': False,
        'mobile_friendly': False,
        'page_speed_good': False,
        'core_web_vitals_good': False
    }
    
    try:
        lighthouse_result = pagespeed_data.get('lighthouseResult', {})
        categories = lighthouse_result.get('categories', {})
        audits = lighthouse_result.get('audits', {})
        
        # Extract scores
        if 'performance' in categories:
            analysis['performance_score'] = int(categories['performance'].get('score', 0) * 100)
        if 'accessibility' in categories:
            analysis['accessibility_score'] = int(categories['accessibility'].get('score', 0) * 100)
        if 'best-practices' in categories:
            analysis['best_practices_score'] = int(categories['best-practices'].get('score', 0) * 100)
        if 'seo' in categories:
            analysis['seo_score'] = int(categories['seo'].get('score', 0) * 100)
        
        # Check for structured data
        if 'structured-data' in audits:
            analysis['structured_data_present'] = audits['structured-data'].get('score', 0) > 0
        
        # Check meta description
        if 'meta-description' in audits:
            analysis['meta_description_present'] = audits['meta-description'].get('score', 0) > 0
        
        # Check heading structure
        if 'heading-order' in audits:
            analysis['heading_structure_good'] = audits['heading-order'].get('score', 0) > 0
        
        # Check mobile friendliness
        if 'viewport' in audits:
            analysis['mobile_friendly'] = audits['viewport'].get('score', 0) > 0
        
        # Check page speed (LCP)
        if 'largest-contentful-paint' in audits:
            lcp_value = audits['largest-contentful-paint'].get('numericValue', 0)
            analysis['page_speed_good'] = lcp_value < 2500  # Good LCP is under 2.5s
        
        # Check Core Web Vitals
        if 'cumulative-layout-shift' in audits and 'first-input-delay' in audits:
            cls_score = audits['cumulative-layout-shift'].get('score', 0)
            fid_score = audits['first-input-delay'].get('score', 0)
            analysis['core_web_vitals_good'] = cls_score > 0.9 and fid_score > 0.9
        
    except Exception as e:
        print(f"Error analyzing PageSpeed data: {e}")
    
    return analysis

def generate_ai_recommendations(analysis, pagespeed_data):
    """Generate AI optimization recommendations based on analysis"""
    recommendations = []
    
    # Performance recommendations
    if analysis['performance_score'] < 90:
        recommendations.append({
            'category': 'Performance',
            'priority': 'High',
            'title': 'Improve Page Speed',
            'description': 'Page speed is crucial for AI search rankings. Optimize images, minify CSS/JS, and use a CDN.',
            'impact': 'High'
        })
    
    # Structured data recommendations
    if not analysis['structured_data_present']:
        recommendations.append({
            'category': 'AI Optimization',
            'priority': 'Critical',
            'title': 'Add Structured Data',
            'description': 'Implement schema markup (JSON-LD) to help AI understand your content. Focus on Article, Organization, and FAQ schemas.',
            'impact': 'Very High'
        })
    
    # SEO recommendations
    if analysis['seo_score'] < 90:
        recommendations.append({
            'category': 'SEO',
            'priority': 'High',
            'title': 'Improve SEO Fundamentals',
            'description': 'Optimize meta tags, headings, and content structure for better AI discovery.',
            'impact': 'High'
        })
    
    # Meta description
    if not analysis['meta_description_present']:
        recommendations.append({
            'category': 'Content',
            'priority': 'Medium',
            'title': 'Add Meta Description',
            'description': 'Write compelling meta descriptions that clearly describe your content for AI systems.',
            'impact': 'Medium'
        })
    
    # Heading structure
    if not analysis['heading_structure_good']:
        recommendations.append({
            'category': 'Content Structure',
            'priority': 'Medium',
            'title': 'Fix Heading Hierarchy',
            'description': 'Use proper H1-H6 heading structure to help AI understand content organization.',
            'impact': 'Medium'
        })
    
    # Mobile optimization
    if not analysis['mobile_friendly']:
        recommendations.append({
            'category': 'Mobile',
            'priority': 'High',
            'title': 'Optimize for Mobile',
            'description': 'Ensure your site is mobile-friendly as AI systems prioritize mobile-optimized content.',
            'impact': 'High'
        })
    
    # Core Web Vitals
    if not analysis['core_web_vitals_good']:
        recommendations.append({
            'category': 'User Experience',
            'priority': 'High',
            'title': 'Improve Core Web Vitals',
            'description': 'Optimize LCP, FID, and CLS metrics for better user experience and AI rankings.',
            'impact': 'High'
        })
    
    return recommendations

def calculate_ai_score(analysis, recommendations):
    """Calculate overall AI optimization score"""
    base_score = (
        analysis['performance_score'] * 0.25 +
        analysis['accessibility_score'] * 0.15 +
        analysis['best_practices_score'] * 0.15 +
        analysis['seo_score'] * 0.25
    ) * 0.6  # 60% from PageSpeed scores
    
    # AI-specific factors (40% of total score)
    ai_factors_score = 0
    if analysis['structured_data_present']:
        ai_factors_score += 15
    if analysis['meta_description_present']:
        ai_factors_score += 5
    if analysis['heading_structure_good']:
        ai_factors_score += 5
    if analysis['mobile_friendly']:
        ai_factors_score += 10
    if analysis['core_web_vitals_good']:
        ai_factors_score += 5
    
    total_score = int(base_score + ai_factors_score)
    return min(100, max(0, total_score))

@scan_bp.route('/scan', methods=['POST'])
def create_scan():
    """Create a new website scan with comprehensive analysis"""
    try:
        data = request.json
        url = validate_url(data.get('url'))
        user_email = data.get('email')  # Optional for free scans
        
        if not url:
            return jsonify({'error': 'Invalid URL provided'}), 400
        
        # Create scan record
        scan = Scan(url=url, user_email=user_email, status='pending')
        db.session.add(scan)
        db.session.commit()
        
        # Initialize comprehensive analyzer
        analyzer = ComprehensiveAnalyzer()
        
        # Perform comprehensive analysis
        analysis_result = analyzer.analyze_website(url)
        
        if not analysis_result['success']:
            scan.status = 'failed'
            scan.error_message = analysis_result.get('error', 'Analysis failed')
            db.session.commit()
            return jsonify({'error': analysis_result.get('error', 'Analysis failed')}), 500
        
        # Extract scores and analysis data
        scores = analysis_result['scores']
        detailed_analysis = analysis_result['detailed_analysis']
        recommendations = analysis_result['recommendations']
        
        # Create legacy format for compatibility
        legacy_analysis = {
            'performance_score': detailed_analysis['seo']['performance_score'],
            'accessibility_score': 85,  # Estimated from SEO analysis
            'best_practices_score': detailed_analysis['seo']['technical_score'],
            'seo_score': detailed_analysis['seo']['score'],
            'structured_data_present': detailed_analysis['aio']['factors']['structured_data_present'],
            'meta_description_present': detailed_analysis['seo']['factors']['meta_description'],
            'heading_structure_good': detailed_analysis['seo']['factors']['heading_structure'],
            'mobile_friendly': True,  # Assumed for modern sites
            'page_speed_good': detailed_analysis['seo']['performance_score'] > 80,
            'core_web_vitals_good': detailed_analysis['seo']['performance_score'] > 85
        }
        
        # Enhanced analysis data
        enhanced_analysis = {
            'comprehensive_scores': scores,
            'detailed_breakdown': detailed_analysis,
            'content_metrics': analysis_result.get('content_metrics', {}),
            'analysis_timestamp': analysis_result['analysis_date']
        }
        
        # Update scan with results
        scan.set_ai_analysis(legacy_analysis)
        scan.set_enhanced_analysis(enhanced_analysis)
        scan.set_recommendations(recommendations)
        scan.score = scores['master_score']
        scan.citation_probability = scores['citation_probability']
        scan.status = 'completed'
        
        db.session.commit()
        
        # Return enhanced response
        response_data = scan.to_dict()
        response_data.update({
            'comprehensive_analysis': analysis_result,
            'optimization_breakdown': {
                'seo_score': scores['seo_score'],
                'aio_score': scores['aio_score'], 
                'geo_score': scores['geo_score'],
                'aeo_score': scores['aeo_score']
            }
        })
        
        return jsonify(response_data), 201
        
    except Exception as e:
        print(f"Scan creation error: {e}")
        # Update scan status if it exists
        if 'scan' in locals():
            scan.status = 'failed'
            scan.error_message = str(e)
            db.session.commit()
        return jsonify({'error': 'Internal server error'}), 500

@scan_bp.route('/scan/<int:scan_id>', methods=['GET'])
def get_scan(scan_id):
    """Get scan results"""
    scan = Scan.query.get_or_404(scan_id)
    return jsonify(scan.to_dict())

@scan_bp.route('/scans', methods=['GET'])
def get_scans():
    """Get all scans for a user"""
    user_email = request.args.get('email')
    if user_email:
        scans = Scan.query.filter_by(user_email=user_email).order_by(Scan.scan_date.desc()).all()
    else:
        # Return recent anonymous scans (limited)
        scans = Scan.query.filter_by(user_email=None).order_by(Scan.scan_date.desc()).limit(10).all()
    
    return jsonify([scan.to_dict() for scan in scans])

@scan_bp.route('/subscription', methods=['POST'])
def create_subscription():
    """Create or update user subscription"""
    try:
        data = request.json
        user_email = data.get('email')
        plan_type = data.get('plan_type', 'free')
        
        if not user_email:
            return jsonify({'error': 'Email is required'}), 400
        
        # Check if subscription exists
        subscription = Subscription.query.filter_by(user_email=user_email).first()
        
        if subscription:
            # Update existing subscription
            subscription.plan_type = plan_type
            if plan_type == 'monthly':
                subscription.scans_limit = -1  # Unlimited
                subscription.expires_date = datetime.utcnow() + timedelta(days=30)
            elif plan_type == 'single':
                subscription.scans_limit = subscription.scans_used + 1
                subscription.expires_date = None
            else:  # free
                subscription.scans_limit = 1
                subscription.expires_date = None
        else:
            # Create new subscription
            scans_limit = -1 if plan_type == 'monthly' else (1 if plan_type == 'free' else 1)
            expires_date = datetime.utcnow() + timedelta(days=30) if plan_type == 'monthly' else None
            
            subscription = Subscription(
                user_email=user_email,
                plan_type=plan_type,
                scans_limit=scans_limit,
                expires_date=expires_date
            )
            db.session.add(subscription)
        
        db.session.commit()
        return jsonify(subscription.to_dict()), 201
        
    except Exception as e:
        print(f"Subscription creation error: {e}")
        return jsonify({'error': 'Internal server error'}), 500

@scan_bp.route('/subscription/<email>', methods=['GET'])
def get_subscription(email):
    """Get user subscription details"""
    subscription = Subscription.query.filter_by(user_email=email).first()
    if not subscription:
        # Create free subscription if none exists
        subscription = Subscription(user_email=email, plan_type='free', scans_limit=1)
        db.session.add(subscription)
        db.session.commit()
    
    return jsonify(subscription.to_dict())

