from flask import Blueprint, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from src.models.user import User, db
from src.models.scan import Subscription
import jwt
import datetime
import os
import re

auth_bp = Blueprint('auth', __name__)

# JWT Secret Key (in production, use environment variable)
JWT_SECRET = os.environ.get('JWT_SECRET', 'your-secret-key-change-in-production')

def validate_email(email):
    """Validate email format"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def generate_token(user_id, email):
    """Generate JWT token for user"""
    payload = {
        'user_id': user_id,
        'email': email,
        'exp': datetime.datetime.utcnow() + datetime.timedelta(days=30)  # Token expires in 30 days
    }
    return jwt.encode(payload, JWT_SECRET, algorithm='HS256')

def verify_token(token):
    """Verify JWT token"""
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
        return payload
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None

@auth_bp.route('/register', methods=['POST'])
def register():
    """Register a new user"""
    try:
        data = request.json
        name = data.get('name', '').strip()
        email = data.get('email', '').strip().lower()
        password = data.get('password', '')

        # Validation
        if not name or len(name) < 2:
            return jsonify({'error': 'Name must be at least 2 characters long'}), 400

        if not email or not validate_email(email):
            return jsonify({'error': 'Please provide a valid email address'}), 400

        if not password or len(password) < 6:
            return jsonify({'error': 'Password must be at least 6 characters long'}), 400

        # Check if user already exists
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            return jsonify({'error': 'An account with this email already exists'}), 409

        # Create new user
        hashed_password = generate_password_hash(password)
        new_user = User(
            username=name,
            email=email
        )

        db.session.add(new_user)
        db.session.commit()

        # Create free subscription for new user
        free_subscription = Subscription(
            user_email=email,
            plan_type='free',
            scans_limit=1,
            scans_used=0,
            status='active'
        )
        db.session.add(free_subscription)
        db.session.commit()

        # Generate token
        token = generate_token(new_user.id, new_user.email)

        return jsonify({
            'message': 'Account created successfully',
            'user': {
                'id': new_user.id,
                'name': new_user.username,
                'email': new_user.email
            },
            'token': token
        }), 201

    except Exception as e:
        print(f"Registration error: {e}")
        db.session.rollback()
        return jsonify({'error': 'Registration failed. Please try again.'}), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    """Login user"""
    try:
        data = request.json
        email = data.get('email', '').strip().lower()
        password = data.get('password', '')

        # Validation
        if not email or not password:
            return jsonify({'error': 'Email and password are required'}), 400

        # Find user
        user = User.query.filter_by(email=email).first()
        if not user:
            return jsonify({'error': 'Invalid email or password'}), 401

        # Check password
        if not check_password_hash(user.password, password):
            return jsonify({'error': 'Invalid email or password'}), 401

        # Generate token
        token = generate_token(user.id, user.email)

        return jsonify({
            'message': 'Login successful',
            'user': {
                'id': user.id,
                'name': user.name,
                'email': user.email,
                'created_at': user.created_at.isoformat()
            },
            'token': token
        }), 200

    except Exception as e:
        print(f"Login error: {e}")
        return jsonify({'error': 'Login failed. Please try again.'}), 500

@auth_bp.route('/verify-token', methods=['POST'])
def verify_user_token():
    """Verify if token is valid"""
    try:
        data = request.json
        token = data.get('token')

        if not token:
            return jsonify({'error': 'Token is required'}), 400

        payload = verify_token(token)
        if not payload:
            return jsonify({'error': 'Invalid or expired token'}), 401

        # Get user details
        user = User.query.get(payload['user_id'])
        if not user:
            return jsonify({'error': 'User not found'}), 404

        return jsonify({
            'valid': True,
            'user': {
                'id': user.id,
                'name': user.name,
                'email': user.email,
                'created_at': user.created_at.isoformat()
            }
        }), 200

    except Exception as e:
        print(f"Token verification error: {e}")
        return jsonify({'error': 'Token verification failed'}), 500

@auth_bp.route('/user-scans/<email>', methods=['GET'])
def get_user_scans(email):
    """Get all scans for a user"""
    try:
        # Verify authorization
        auth_header = request.headers.get('Authorization')
        if not auth_header or not auth_header.startswith('Bearer '):
            return jsonify({'error': 'Authorization token required'}), 401

        token = auth_header.split(' ')[1]
        payload = verify_token(token)
        if not payload or payload['email'] != email:
            return jsonify({'error': 'Unauthorized'}), 403

        # Get user's scans
        from src.models.scan import Scan
        scans = Scan.query.filter_by(user_email=email).order_by(Scan.scan_date.desc()).all()

        return jsonify({
            'scans': [scan.to_dict() for scan in scans]
        }), 200

    except Exception as e:
        print(f"Get user scans error: {e}")
        return jsonify({'error': 'Failed to retrieve scans'}), 500

@auth_bp.route('/profile', methods=['GET'])
def get_profile():
    """Get user profile"""
    try:
        # Verify authorization
        auth_header = request.headers.get('Authorization')
        if not auth_header or not auth_header.startswith('Bearer '):
            return jsonify({'error': 'Authorization token required'}), 401

        token = auth_header.split(' ')[1]
        payload = verify_token(token)
        if not payload:
            return jsonify({'error': 'Invalid or expired token'}), 401

        # Get user
        user = User.query.get(payload['user_id'])
        if not user:
            return jsonify({'error': 'User not found'}), 404

        return jsonify({
            'user': {
                'id': user.id,
                'name': user.name,
                'email': user.email,
                'created_at': user.created_at.isoformat()
            }
        }), 200

    except Exception as e:
        print(f"Get profile error: {e}")
        return jsonify({'error': 'Failed to get profile'}), 500

@auth_bp.route('/update-profile', methods=['PUT'])
def update_profile():
    """Update user profile"""
    try:
        # Verify authorization
        auth_header = request.headers.get('Authorization')
        if not auth_header or not auth_header.startswith('Bearer '):
            return jsonify({'error': 'Authorization token required'}), 401

        token = auth_header.split(' ')[1]
        payload = verify_token(token)
        if not payload:
            return jsonify({'error': 'Invalid or expired token'}), 401

        # Get user
        user = User.query.get(payload['user_id'])
        if not user:
            return jsonify({'error': 'User not found'}), 404

        # Update user data
        data = request.json
        name = data.get('name', '').strip()

        if name and len(name) >= 2:
            user.name = name

        db.session.commit()

        return jsonify({
            'message': 'Profile updated successfully',
            'user': {
                'id': user.id,
                'name': user.name,
                'email': user.email,
                'created_at': user.created_at.isoformat()
            }
        }), 200

    except Exception as e:
        print(f"Update profile error: {e}")
        db.session.rollback()
        return jsonify({'error': 'Failed to update profile'}), 500



@auth_bp.route('/subscription-status/<email>', methods=['GET'])
def get_subscription_status(email):
    """Get subscription status for a user"""
    try:
        # Verify authorization
        auth_header = request.headers.get('Authorization')
        if not auth_header or not auth_header.startswith('Bearer '):
            return jsonify({'error': 'Authorization token required'}), 401

        token = auth_header.split(' ')[1]
        payload = verify_token(token)
        if not payload or payload['email'] != email:
            return jsonify({'error': 'Unauthorized'}), 403

        # Get user's subscription
        subscription = Subscription.query.filter_by(user_email=email).first()
        
        if not subscription:
            # Create default free subscription if none exists
            subscription = Subscription(
                user_email=email,
                plan_type='free',
                scans_limit=1,
                scans_used=0,
                status='active'
            )
            db.session.add(subscription)
            db.session.commit()

        return jsonify({
            'subscription': subscription.to_dict()
        }), 200

    except Exception as e:
        print(f"Get subscription status error: {e}")
        return jsonify({'error': 'Failed to retrieve subscription status'}), 500

