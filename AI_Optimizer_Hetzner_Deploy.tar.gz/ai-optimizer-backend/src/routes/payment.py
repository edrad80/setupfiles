from flask import Blueprint, jsonify, request, redirect
from src.models.scan import Subscription, db
import stripe
import os
from datetime import datetime, timedelta

payment_bp = Blueprint('payment', __name__)

# Stripe configuration
stripe.api_key = os.environ.get('STRIPE_SECRET_KEY', 'sk_test_...')  # Replace with your test key
STRIPE_PUBLISHABLE_KEY = os.environ.get('STRIPE_PUBLISHABLE_KEY', 'pk_test_...')  # Replace with your test key

# For demo purposes, we'll use mock price IDs
# In production, create these in your Stripe dashboard
STRIPE_PRICES = {
    'single': 'price_1234567890',  # £1.99 one-time payment
    'monthly': 'price_0987654321'  # £15/month subscription
}

@payment_bp.route('/config', methods=['GET'])
def get_stripe_config():
    """Get Stripe publishable key for frontend"""
    return jsonify({
        'publishable_key': STRIPE_PUBLISHABLE_KEY
    })

@payment_bp.route('/create-checkout-session', methods=['POST'])
def create_checkout_session():
    """Create Stripe checkout session"""
    try:
        data = request.json
        plan_type = data.get('plan_type')  # 'single' or 'monthly'
        user_email = data.get('email')
        success_url = data.get('success_url', 'http://localhost:5173/success')
        cancel_url = data.get('cancel_url', 'http://localhost:5173/cancel')
        
        if not plan_type or plan_type not in ['single', 'monthly']:
            return jsonify({'error': 'Invalid plan type'}), 400
        
        if not user_email:
            return jsonify({'error': 'Email is required'}), 400
        
        # For demo purposes, we'll create a mock checkout session
        # In production, you would use the actual Stripe API
        
        if plan_type == 'single':
            # One-time payment for single scan
            checkout_session = {
                'id': f'cs_test_single_{user_email}',
                'url': f'{success_url}?session_id=cs_test_single_{user_email}&plan=single',
                'mode': 'payment',
                'amount_total': 199,  # £1.99 in pence
                'currency': 'gbp'
            }
        else:  # monthly
            # Subscription payment
            checkout_session = {
                'id': f'cs_test_monthly_{user_email}',
                'url': f'{success_url}?session_id=cs_test_monthly_{user_email}&plan=monthly',
                'mode': 'subscription',
                'amount_total': 1500,  # £15.00 in pence
                'currency': 'gbp'
            }
        
        # In production, you would create the actual Stripe checkout session like this:
        # checkout_session = stripe.checkout.Session.create(
        #     payment_method_types=['card'],
        #     line_items=[{
        #         'price': STRIPE_PRICES[plan_type],
        #         'quantity': 1,
        #     }],
        #     mode='subscription' if plan_type == 'monthly' else 'payment',
        #     success_url=success_url + '?session_id={CHECKOUT_SESSION_ID}',
        #     cancel_url=cancel_url,
        #     customer_email=user_email,
        #     metadata={
        #         'user_email': user_email,
        #         'plan_type': plan_type
        #     }
        # )
        
        return jsonify({
            'checkout_url': checkout_session['url'],
            'session_id': checkout_session['id']
        })
        
    except Exception as e:
        print(f"Checkout session creation error: {e}")
        return jsonify({'error': 'Failed to create checkout session'}), 500

@payment_bp.route('/webhook', methods=['POST'])
def stripe_webhook():
    """Handle Stripe webhooks"""
    try:
        payload = request.get_data()
        sig_header = request.headers.get('Stripe-Signature')
        
        # In production, verify the webhook signature:
        # event = stripe.Webhook.construct_event(
        #     payload, sig_header, os.environ.get('STRIPE_WEBHOOK_SECRET')
        # )
        
        # For demo purposes, we'll simulate webhook handling
        event_type = request.json.get('type', 'checkout.session.completed')
        
        if event_type == 'checkout.session.completed':
            session = request.json.get('data', {}).get('object', {})
            handle_successful_payment(session)
        
        return jsonify({'status': 'success'})
        
    except Exception as e:
        print(f"Webhook error: {e}")
        return jsonify({'error': 'Webhook handling failed'}), 400

def handle_successful_payment(session):
    """Handle successful payment from webhook"""
    try:
        # Extract customer information
        customer_email = session.get('customer_email')
        session_id = session.get('id', '')
        
        # Determine plan type from session ID (in demo)
        if 'single' in session_id:
            plan_type = 'single'
            scans_limit = 1
            expires_date = None
        elif 'monthly' in session_id:
            plan_type = 'monthly'
            scans_limit = -1  # Unlimited
            expires_date = datetime.utcnow() + timedelta(days=30)
        else:
            return
        
        # Update or create subscription
        subscription = Subscription.query.filter_by(user_email=customer_email).first()
        
        if subscription:
            subscription.plan_type = plan_type
            subscription.scans_limit = scans_limit
            subscription.expires_date = expires_date
            subscription.status = 'active'
            if plan_type == 'single':
                subscription.scans_used = 0  # Reset for new single purchase
        else:
            subscription = Subscription(
                user_email=customer_email,
                plan_type=plan_type,
                scans_limit=scans_limit,
                expires_date=expires_date,
                status='active'
            )
            db.session.add(subscription)
        
        db.session.commit()
        print(f"Successfully updated subscription for {customer_email}")
        
    except Exception as e:
        print(f"Payment handling error: {e}")

@payment_bp.route('/payment-success', methods=['POST'])
def payment_success():
    """Handle successful payment confirmation from frontend"""
    try:
        data = request.json
        session_id = data.get('session_id')
        user_email = data.get('email')
        
        if not session_id or not user_email:
            return jsonify({'error': 'Missing required data'}), 400
        
        # Simulate successful payment processing
        if 'single' in session_id:
            plan_type = 'single'
            scans_limit = 1
            expires_date = None
        elif 'monthly' in session_id:
            plan_type = 'monthly'
            scans_limit = -1
            expires_date = datetime.utcnow() + timedelta(days=30)
        else:
            return jsonify({'error': 'Invalid session'}), 400
        
        # Update subscription
        subscription = Subscription.query.filter_by(user_email=user_email).first()
        
        if subscription:
            subscription.plan_type = plan_type
            subscription.scans_limit = scans_limit
            subscription.expires_date = expires_date
            subscription.status = 'active'
            if plan_type == 'single':
                subscription.scans_used = 0
        else:
            subscription = Subscription(
                user_email=user_email,
                plan_type=plan_type,
                scans_limit=scans_limit,
                expires_date=expires_date,
                status='active'
            )
            db.session.add(subscription)
        
        db.session.commit()
        
        return jsonify({
            'status': 'success',
            'subscription': subscription.to_dict()
        })
        
    except Exception as e:
        print(f"Payment success handling error: {e}")
        return jsonify({'error': 'Failed to process payment'}), 500

@payment_bp.route('/subscription-status/<email>', methods=['GET'])
def get_subscription_status(email):
    """Get current subscription status for a user"""
    try:
        subscription = Subscription.query.filter_by(user_email=email).first()
        
        if not subscription:
            # Create free subscription if none exists
            subscription = Subscription(
                user_email=email,
                plan_type='free',
                scans_limit=1,
                status='active'
            )
            db.session.add(subscription)
            db.session.commit()
        
        return jsonify({
            'subscription': subscription.to_dict(),
            'can_scan': subscription.can_scan()
        })
        
    except Exception as e:
        print(f"Subscription status error: {e}")
        return jsonify({'error': 'Failed to get subscription status'}), 500

