"""
Comprehensive AI Optimization Analysis Engine
Implements SEO, AIO, GEO, and AEO analysis capabilities
"""

import requests
import json
import re
from urllib.parse import urlparse, urljoin
from bs4 import BeautifulSoup
import time
from datetime import datetime, timedelta
import math

class ComprehensiveAnalyzer:
    """Main analysis engine for comprehensive optimization assessment"""
    
    def __init__(self):
        self.user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        
    def analyze_website(self, url):
        """
        Perform comprehensive analysis across all four optimization areas
        Returns detailed analysis results and recommendations
        """
        try:
            # Fetch website content
            content_data = self._fetch_website_content(url)
            if not content_data:
                return self._create_error_response("Failed to fetch website content")
            
            # Perform individual analyses
            seo_analysis = self._analyze_seo_foundation(content_data)
            aio_analysis = self._analyze_aio_optimization(content_data)
            geo_analysis = self._analyze_geo_optimization(content_data)
            aeo_analysis = self._analyze_aeo_optimization(content_data)
            
            # Calculate comprehensive scores
            component_scores = {
                'seo': seo_analysis['score'],
                'aio': aio_analysis['score'],
                'geo': geo_analysis['score'],
                'aeo': aeo_analysis['score']
            }
            
            master_score = self._calculate_master_score(component_scores, content_data.get('content_type', 'general'))
            citation_probability = self._calculate_citation_probability(component_scores, content_data)
            
            # Generate comprehensive recommendations
            recommendations = self._generate_comprehensive_recommendations(
                seo_analysis, aio_analysis, geo_analysis, aeo_analysis
            )
            
            return {
                'success': True,
                'url': url,
                'analysis_date': datetime.utcnow().isoformat(),
                'scores': {
                    'master_score': master_score,
                    'seo_score': seo_analysis['score'],
                    'aio_score': aio_analysis['score'],
                    'geo_score': geo_analysis['score'],
                    'aeo_score': aeo_analysis['score'],
                    'citation_probability': citation_probability
                },
                'detailed_analysis': {
                    'seo': seo_analysis,
                    'aio': aio_analysis,
                    'geo': geo_analysis,
                    'aeo': aeo_analysis
                },
                'recommendations': recommendations,
                'content_metrics': content_data.get('metrics', {})
            }
            
        except Exception as e:
            return self._create_error_response(f"Analysis error: {str(e)}")
    
    def _fetch_website_content(self, url):
        """Fetch and parse website content for analysis"""
        try:
            headers = {'User-Agent': self.user_agent}
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extract basic content data
            content_data = {
                'url': url,
                'html': response.text,
                'soup': soup,
                'status_code': response.status_code,
                'response_time': response.elapsed.total_seconds(),
                'content_length': len(response.content),
                'content_type': self._detect_content_type(soup),
                'metrics': self._extract_content_metrics(soup, response.text)
            }
            
            return content_data
            
        except Exception as e:
            print(f"Error fetching content: {e}")
            return None
    
    def _detect_content_type(self, soup):
        """Detect content type for optimization weighting"""
        # Check for e-commerce indicators
        if soup.find(['div', 'span'], class_=re.compile(r'price|cart|product|shop', re.I)):
            return 'ecommerce'
        
        # Check for news indicators
        if soup.find(['time', 'div'], class_=re.compile(r'date|publish|news', re.I)):
            return 'news'
        
        # Check for local business indicators
        if soup.find(['div', 'span'], class_=re.compile(r'address|location|contact', re.I)):
            return 'local'
        
        return 'general'
    
    def _extract_content_metrics(self, soup, html_content):
        """Extract basic content metrics for analysis"""
        text_content = soup.get_text()
        
        return {
            'word_count': len(text_content.split()),
            'character_count': len(text_content),
            'paragraph_count': len(soup.find_all('p')),
            'heading_count': len(soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])),
            'link_count': len(soup.find_all('a')),
            'image_count': len(soup.find_all('img')),
            'html_size': len(html_content)
        }
    
    def _analyze_seo_foundation(self, content_data):
        """Analyze SEO foundation factors"""
        soup = content_data['soup']
        
        # Technical SEO analysis
        technical_score = self._analyze_technical_seo(content_data)
        
        # Content SEO analysis
        content_score = self._analyze_content_seo(soup)
        
        # Performance analysis (simulated)
        performance_score = self._analyze_performance(content_data)
        
        # Calculate weighted SEO score
        seo_score = (technical_score * 0.4 + content_score * 0.4 + performance_score * 0.2)
        
        return {
            'score': round(seo_score, 1),
            'technical_score': technical_score,
            'content_score': content_score,
            'performance_score': performance_score,
            'factors': {
                'title_optimized': bool(soup.find('title')),
                'meta_description': bool(soup.find('meta', attrs={'name': 'description'})),
                'heading_structure': self._check_heading_structure(soup),
                'internal_links': len(soup.find_all('a', href=True)) > 0,
                'image_alt_tags': self._check_image_alt_tags(soup)
            }
        }
    
    def _analyze_technical_seo(self, content_data):
        """Analyze technical SEO factors"""
        soup = content_data['soup']
        score = 0
        
        # URL structure (basic check)
        url = content_data['url']
        if len(url) < 100 and not re.search(r'[?&=]', url.split('/')[-1]):
            score += 15
        
        # Title tag
        title = soup.find('title')
        if title and 30 <= len(title.get_text()) <= 60:
            score += 20
        elif title:
            score += 10
        
        # Meta description
        meta_desc = soup.find('meta', attrs={'name': 'description'})
        if meta_desc and 120 <= len(meta_desc.get('content', '')) <= 160:
            score += 20
        elif meta_desc:
            score += 10
        
        # Canonical tag
        if soup.find('link', attrs={'rel': 'canonical'}):
            score += 10
        
        # Robots meta
        robots_meta = soup.find('meta', attrs={'name': 'robots'})
        if not robots_meta or 'noindex' not in robots_meta.get('content', '').lower():
            score += 10
        
        # SSL (assumed if HTTPS)
        if content_data['url'].startswith('https://'):
            score += 15
        
        # Mobile viewport
        if soup.find('meta', attrs={'name': 'viewport'}):
            score += 10
        
        return min(100, score)
    
    def _analyze_content_seo(self, soup):
        """Analyze content SEO factors"""
        score = 0
        
        # Heading structure
        if self._check_heading_structure(soup):
            score += 25
        
        # Content length
        text_content = soup.get_text()
        word_count = len(text_content.split())
        if word_count >= 300:
            score += 20
        if word_count >= 1000:
            score += 10
        
        # Internal linking
        internal_links = len([a for a in soup.find_all('a', href=True) 
                            if not a['href'].startswith(('http://', 'https://'))])
        if internal_links >= 3:
            score += 15
        
        # Image optimization
        if self._check_image_alt_tags(soup):
            score += 15
        
        # Content structure
        paragraphs = soup.find_all('p')
        if len(paragraphs) >= 3:
            score += 15
        
        return min(100, score)
    
    def _analyze_performance(self, content_data):
        """Analyze performance factors (simulated)"""
        score = 80  # Base score
        
        # Response time factor
        response_time = content_data.get('response_time', 2.0)
        if response_time < 1.0:
            score += 20
        elif response_time < 2.0:
            score += 10
        elif response_time > 3.0:
            score -= 20
        
        # Content size factor
        content_size = content_data.get('content_length', 50000)
        if content_size < 100000:  # Less than 100KB
            score += 10
        elif content_size > 500000:  # More than 500KB
            score -= 15
        
        return min(100, max(0, score))
    
    def _analyze_aio_optimization(self, content_data):
        """Analyze AI Overview Optimization factors"""
        soup = content_data['soup']
        
        # Schema markup analysis
        schema_score = self._analyze_schema_markup(soup)
        
        # E-E-A-T signals analysis
        eeat_score = self._analyze_eeat_signals(soup)
        
        # Content structure for AI
        structure_score = self._analyze_ai_content_structure(soup)
        
        # Calculate weighted AIO score
        aio_score = (schema_score * 0.4 + eeat_score * 0.35 + structure_score * 0.25)
        
        return {
            'score': round(aio_score, 1),
            'schema_score': schema_score,
            'eeat_score': eeat_score,
            'structure_score': structure_score,
            'factors': {
                'structured_data_present': self._has_structured_data(soup),
                'author_information': self._has_author_info(soup),
                'publication_date': self._has_publication_date(soup),
                'faq_format': self._has_faq_format(soup),
                'clear_headings': self._check_heading_structure(soup)
            }
        }
    
    def _analyze_schema_markup(self, soup):
        """Analyze schema markup implementation"""
        score = 0
        
        # JSON-LD detection
        json_ld_scripts = soup.find_all('script', type='application/ld+json')
        if json_ld_scripts:
            score += 40
            
            # Check for specific schema types
            for script in json_ld_scripts:
                try:
                    schema_data = json.loads(script.string)
                    schema_type = schema_data.get('@type', '').lower()
                    
                    if schema_type in ['article', 'newsarticle', 'blogposting']:
                        score += 15
                    if schema_type in ['organization', 'person']:
                        score += 10
                    if schema_type == 'faqpage':
                        score += 15
                    if schema_type in ['product', 'offer']:
                        score += 10
                        
                except json.JSONDecodeError:
                    pass
        
        # Microdata detection
        if soup.find(attrs={'itemscope': True}):
            score += 20
        
        # RDFa detection
        if soup.find(attrs={'typeof': True}):
            score += 15
        
        return min(100, score)
    
    def _analyze_eeat_signals(self, soup):
        """Analyze E-E-A-T signals"""
        score = 0
        
        # Author information
        if self._has_author_info(soup):
            score += 25
        
        # Publication/update dates
        if self._has_publication_date(soup):
            score += 20
        
        # Contact information
        if self._has_contact_info(soup):
            score += 15
        
        # About page link
        about_link = soup.find('a', href=re.compile(r'/about|about\.', re.I))
        if about_link:
            score += 10
        
        # Privacy policy link
        privacy_link = soup.find('a', href=re.compile(r'/privacy|privacy\.', re.I))
        if privacy_link:
            score += 10
        
        # External citations
        external_links = [a for a in soup.find_all('a', href=True) 
                         if a['href'].startswith(('http://', 'https://'))]
        if len(external_links) >= 3:
            score += 20
        
        return min(100, score)
    
    def _analyze_ai_content_structure(self, soup):
        """Analyze content structure for AI understanding"""
        score = 0
        
        # Clear heading hierarchy
        if self._check_heading_structure(soup):
            score += 30
        
        # FAQ format
        if self._has_faq_format(soup):
            score += 25
        
        # List structures
        lists = soup.find_all(['ul', 'ol'])
        if len(lists) >= 2:
            score += 20
        
        # Table structures
        tables = soup.find_all('table')
        if tables:
            score += 15
        
        # Clear paragraphs
        paragraphs = soup.find_all('p')
        if len(paragraphs) >= 3:
            score += 10
        
        return min(100, score)
    
    def _analyze_geo_optimization(self, content_data):
        """Analyze Generative Engine Optimization factors"""
        soup = content_data['soup']
        
        # Authority signals
        authority_score = self._analyze_authority_signals(soup, content_data)
        
        # Content credibility
        credibility_score = self._analyze_content_credibility(soup)
        
        # Freshness and accuracy
        freshness_score = self._analyze_content_freshness(soup)
        
        # Calculate weighted GEO score
        geo_score = (authority_score * 0.4 + credibility_score * 0.35 + freshness_score * 0.25)
        
        return {
            'score': round(geo_score, 1),
            'authority_score': authority_score,
            'credibility_score': credibility_score,
            'freshness_score': freshness_score,
            'factors': {
                'author_credentials': self._has_author_credentials(soup),
                'citation_quality': self._has_quality_citations(soup),
                'content_freshness': self._has_recent_dates(soup),
                'transparency': self._has_transparency_signals(soup),
                'expertise_indicators': self._has_expertise_indicators(soup)
            }
        }
    
    def _analyze_authority_signals(self, soup, content_data):
        """Analyze authority signals"""
        score = 0
        
        # Domain age simulation (based on URL structure)
        url = content_data['url']
        domain = urlparse(url).netloc
        if not re.search(r'\d{4}', domain):  # No year in domain suggests established site
            score += 20
        
        # Author bylines
        if self._has_author_info(soup):
            score += 25
        
        # Professional credentials
        if self._has_author_credentials(soup):
            score += 20
        
        # Contact information
        if self._has_contact_info(soup):
            score += 15
        
        # SSL (HTTPS)
        if content_data['url'].startswith('https://'):
            score += 10
        
        # Privacy policy
        if soup.find('a', href=re.compile(r'/privacy|privacy\.', re.I)):
            score += 10
        
        return min(100, score)
    
    def _analyze_content_credibility(self, soup):
        """Analyze content credibility indicators"""
        score = 0
        
        # Citations and references
        if self._has_quality_citations(soup):
            score += 30
        
        # Fact-checking indicators
        if soup.find(text=re.compile(r'fact.?check|verified|source', re.I)):
            score += 20
        
        # Editorial standards
        if soup.find('a', href=re.compile(r'/editorial|standards|guidelines', re.I)):
            score += 15
        
        # Correction policy
        if soup.find(text=re.compile(r'correction|update|edit', re.I)):
            score += 10
        
        # Transparency about funding/conflicts
        if soup.find(text=re.compile(r'disclosure|conflict|funding', re.I)):
            score += 15
        
        # Professional language and tone
        text_content = soup.get_text()
        if len(text_content.split()) > 300:  # Substantial content
            score += 10
        
        return min(100, score)
    
    def _analyze_content_freshness(self, soup):
        """Analyze content freshness and accuracy"""
        score = 0
        
        # Publication date
        if self._has_publication_date(soup):
            score += 30
        
        # Last updated date
        if self._has_update_date(soup):
            score += 25
        
        # Recent references
        current_year = datetime.now().year
        if soup.find(text=re.compile(rf'{current_year}|{current_year-1}')):
            score += 20
        
        # Timely content indicators
        if soup.find(text=re.compile(r'latest|recent|current|updated', re.I)):
            score += 15
        
        # Version or revision indicators
        if soup.find(text=re.compile(r'version|revision|v\d+', re.I)):
            score += 10
        
        return min(100, score)
    
    def _analyze_aeo_optimization(self, content_data):
        """Analyze Answer Engine Optimization factors"""
        soup = content_data['soup']
        
        # Question-answer format
        qa_score = self._analyze_qa_format(soup)
        
        # Voice search optimization
        voice_score = self._analyze_voice_optimization(soup)
        
        # Featured snippet optimization
        snippet_score = self._analyze_snippet_optimization(soup)
        
        # Calculate weighted AEO score
        aeo_score = (qa_score * 0.4 + voice_score * 0.3 + snippet_score * 0.3)
        
        return {
            'score': round(aeo_score, 1),
            'qa_score': qa_score,
            'voice_score': voice_score,
            'snippet_score': snippet_score,
            'factors': {
                'faq_present': self._has_faq_format(soup),
                'question_headings': self._has_question_headings(soup),
                'direct_answers': self._has_direct_answers(soup),
                'conversational_tone': self._has_conversational_tone(soup),
                'list_format': len(soup.find_all(['ul', 'ol'])) > 0
            }
        }
    
    def _analyze_qa_format(self, soup):
        """Analyze question-answer format optimization"""
        score = 0
        
        # FAQ section
        if self._has_faq_format(soup):
            score += 40
        
        # Question headings
        if self._has_question_headings(soup):
            score += 30
        
        # Direct answers
        if self._has_direct_answers(soup):
            score += 20
        
        # FAQ schema
        json_ld_scripts = soup.find_all('script', type='application/ld+json')
        for script in json_ld_scripts:
            try:
                schema_data = json.loads(script.string)
                if schema_data.get('@type', '').lower() == 'faqpage':
                    score += 10
                    break
            except json.JSONDecodeError:
                pass
        
        return min(100, score)
    
    def _analyze_voice_optimization(self, soup):
        """Analyze voice search optimization"""
        score = 0
        
        # Conversational tone
        if self._has_conversational_tone(soup):
            score += 30
        
        # Question-based content
        if self._has_question_headings(soup):
            score += 25
        
        # Local optimization (for voice search)
        if self._has_local_indicators(soup):
            score += 20
        
        # Natural language patterns
        text_content = soup.get_text().lower()
        voice_patterns = ['how to', 'what is', 'where can', 'when does', 'why should']
        pattern_count = sum(1 for pattern in voice_patterns if pattern in text_content)
        score += min(15, pattern_count * 3)
        
        # Concise answers
        paragraphs = soup.find_all('p')
        short_paragraphs = [p for p in paragraphs if len(p.get_text().split()) <= 30]
        if len(short_paragraphs) >= 3:
            score += 10
        
        return min(100, score)
    
    def _analyze_snippet_optimization(self, soup):
        """Analyze featured snippet optimization"""
        score = 0
        
        # List structures
        lists = soup.find_all(['ul', 'ol'])
        if len(lists) >= 2:
            score += 25
        
        # Table structures
        tables = soup.find_all('table')
        if tables:
            score += 25
        
        # Definition format
        if self._has_definition_format(soup):
            score += 20
        
        # Step-by-step format
        if self._has_step_format(soup):
            score += 15
        
        # Comparison format
        if self._has_comparison_format(soup):
            score += 15
        
        return min(100, score)
    
    # Helper methods for content analysis
    
    def _check_heading_structure(self, soup):
        """Check if heading structure is logical"""
        headings = soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])
        if not headings:
            return False
        
        # Check for H1
        h1_count = len(soup.find_all('h1'))
        if h1_count != 1:
            return False
        
        # Check for logical hierarchy
        heading_levels = [int(h.name[1]) for h in headings]
        return len(heading_levels) >= 2 and max(heading_levels) - min(heading_levels) <= 3
    
    def _check_image_alt_tags(self, soup):
        """Check if images have alt tags"""
        images = soup.find_all('img')
        if not images:
            return True  # No images to check
        
        images_with_alt = [img for img in images if img.get('alt')]
        return len(images_with_alt) / len(images) >= 0.8
    
    def _has_structured_data(self, soup):
        """Check for any structured data"""
        return (bool(soup.find_all('script', type='application/ld+json')) or
                bool(soup.find(attrs={'itemscope': True})) or
                bool(soup.find(attrs={'typeof': True})))
    
    def _has_author_info(self, soup):
        """Check for author information"""
        author_indicators = ['author', 'by-author', 'writer', 'byline']
        return any(soup.find(class_=re.compile(indicator, re.I)) for indicator in author_indicators)
    
    def _has_author_credentials(self, soup):
        """Check for author credentials"""
        credential_terms = ['phd', 'md', 'professor', 'expert', 'certified', 'specialist']
        text_content = soup.get_text().lower()
        return any(term in text_content for term in credential_terms)
    
    def _has_publication_date(self, soup):
        """Check for publication date"""
        return (bool(soup.find('time')) or
                bool(soup.find(class_=re.compile(r'date|publish', re.I))) or
                bool(soup.find(attrs={'datetime': True})))
    
    def _has_update_date(self, soup):
        """Check for last updated date"""
        return bool(soup.find(text=re.compile(r'updated|modified|revised', re.I)))
    
    def _has_contact_info(self, soup):
        """Check for contact information"""
        return (bool(soup.find('a', href=re.compile(r'mailto:|tel:'))) or
                bool(soup.find(text=re.compile(r'contact|email|phone', re.I))))
    
    def _has_quality_citations(self, soup):
        """Check for quality external citations"""
        external_links = [a for a in soup.find_all('a', href=True) 
                         if a['href'].startswith(('http://', 'https://'))]
        
        # Check for authoritative domains
        authoritative_domains = ['.edu', '.gov', '.org']
        quality_links = [link for link in external_links 
                        if any(domain in link['href'] for domain in authoritative_domains)]
        
        return len(quality_links) >= 2
    
    def _has_recent_dates(self, soup):
        """Check for recent dates in content"""
        current_year = datetime.now().year
        return bool(soup.find(text=re.compile(rf'{current_year}|{current_year-1}')))
    
    def _has_transparency_signals(self, soup):
        """Check for transparency indicators"""
        transparency_terms = ['disclosure', 'privacy', 'terms', 'about']
        return any(soup.find('a', href=re.compile(term, re.I)) for term in transparency_terms)
    
    def _has_expertise_indicators(self, soup):
        """Check for expertise indicators"""
        expertise_terms = ['expert', 'professional', 'certified', 'qualified', 'experienced']
        text_content = soup.get_text().lower()
        return any(term in text_content for term in expertise_terms)
    
    def _has_faq_format(self, soup):
        """Check for FAQ format"""
        return (bool(soup.find(text=re.compile(r'faq|frequently asked', re.I))) or
                bool(soup.find(class_=re.compile(r'faq', re.I))))
    
    def _has_question_headings(self, soup):
        """Check for question-based headings"""
        headings = soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])
        question_headings = [h for h in headings if re.search(r'\?|how|what|when|where|why|who', h.get_text(), re.I)]
        return len(question_headings) >= 2
    
    def _has_direct_answers(self, soup):
        """Check for direct answer format"""
        paragraphs = soup.find_all('p')
        short_answers = [p for p in paragraphs if 10 <= len(p.get_text().split()) <= 50]
        return len(short_answers) >= 3
    
    def _has_conversational_tone(self, soup):
        """Check for conversational tone"""
        text_content = soup.get_text().lower()
        conversational_indicators = ['you', 'your', 'we', 'our', 'let\'s', 'here\'s']
        return sum(text_content.count(indicator) for indicator in conversational_indicators) >= 5
    
    def _has_local_indicators(self, soup):
        """Check for local business indicators"""
        local_terms = ['address', 'location', 'near me', 'local', 'city', 'state']
        text_content = soup.get_text().lower()
        return any(term in text_content for term in local_terms)
    
    def _has_definition_format(self, soup):
        """Check for definition format"""
        return bool(soup.find(text=re.compile(r'is defined as|means|refers to|is a', re.I)))
    
    def _has_step_format(self, soup):
        """Check for step-by-step format"""
        return (bool(soup.find(text=re.compile(r'step \d+|first|second|third|next|finally', re.I))) or
                bool(soup.find('ol')))
    
    def _has_comparison_format(self, soup):
        """Check for comparison format"""
        return (bool(soup.find('table')) or
                bool(soup.find(text=re.compile(r'vs|versus|compared to|difference', re.I))))
    
    def _calculate_master_score(self, component_scores, content_type='general'):
        """Calculate comprehensive AI optimization score"""
        # Base weightings
        base_weights = {
            'seo': 0.25,
            'aio': 0.30,
            'geo': 0.25,
            'aeo': 0.20
        }
        
        # Content type adjustments
        if content_type == 'ecommerce':
            weights = {
                'seo': 0.30,
                'aio': 0.35,
                'geo': 0.20,
                'aeo': 0.15
            }
        elif content_type == 'news':
            weights = {
                'seo': 0.20,
                'aio': 0.25,
                'geo': 0.35,
                'aeo': 0.20
            }
        elif content_type == 'local':
            weights = {
                'seo': 0.25,
                'aio': 0.25,
                'geo': 0.25,
                'aeo': 0.25
            }
        else:
            weights = base_weights
        
        # Calculate weighted score
        total_score = (
            component_scores['seo'] * weights['seo'] +
            component_scores['aio'] * weights['aio'] +
            component_scores['geo'] * weights['geo'] +
            component_scores['aeo'] * weights['aeo']
        )
        
        # Apply bonus factors
        bonus_score = 0
        
        # Comprehensive optimization bonus
        if all(score >= 80 for score in component_scores.values()):
            bonus_score += 5
        
        # Consistency bonus
        score_variance = max(component_scores.values()) - min(component_scores.values())
        if score_variance <= 20:
            bonus_score += 3
        
        final_score = min(100, total_score + bonus_score)
        return round(final_score, 1)
    
    def _calculate_citation_probability(self, optimization_scores, content_data):
        """Calculate AI citation probability"""
        # Base probability from optimization scores
        base_probability = (
            optimization_scores['seo'] / 100 * 0.2 +
            optimization_scores['aio'] / 100 * 0.3 +
            optimization_scores['geo'] / 100 * 0.3 +
            optimization_scores['aeo'] / 100 * 0.2
        )
        
        # Content quality factors
        quality_factor = 1.0
        metrics = content_data.get('metrics', {})
        
        if metrics.get('word_count', 0) >= 1500:
            quality_factor += 0.1
        if metrics.get('heading_count', 0) >= 5:
            quality_factor += 0.05
        if content_data.get('response_time', 3.0) <= 2.0:
            quality_factor += 0.05
        
        # Calculate final probability
        citation_probability = base_probability * quality_factor
        
        # Apply bounds
        final_probability = min(0.95, max(0.05, citation_probability))
        
        return round(final_probability * 100, 1)
    
    def _generate_comprehensive_recommendations(self, seo_analysis, aio_analysis, geo_analysis, aeo_analysis):
        """Generate prioritized recommendations across all areas"""
        recommendations = []
        
        # SEO recommendations
        if seo_analysis['score'] < 80:
            if not seo_analysis['factors']['title_optimized']:
                recommendations.append({
                    'category': 'SEO Foundation',
                    'priority': 'High',
                    'title': 'Optimize Title Tag',
                    'description': 'Add a descriptive title tag (30-60 characters) that includes your primary keyword.',
                    'impact': 'High',
                    'difficulty': 'Easy'
                })
            
            if not seo_analysis['factors']['meta_description']:
                recommendations.append({
                    'category': 'SEO Foundation',
                    'priority': 'High',
                    'title': 'Add Meta Description',
                    'description': 'Write a compelling meta description (120-160 characters) that summarizes your content.',
                    'impact': 'Medium',
                    'difficulty': 'Easy'
                })
        
        # AIO recommendations
        if aio_analysis['score'] < 80:
            if not aio_analysis['factors']['structured_data_present']:
                recommendations.append({
                    'category': 'AI Overview Optimization',
                    'priority': 'Critical',
                    'title': 'Implement Schema Markup',
                    'description': 'Add JSON-LD structured data to help AI systems understand your content. Start with Article or Organization schema.',
                    'impact': 'Very High',
                    'difficulty': 'Medium'
                })
            
            if not aio_analysis['factors']['author_information']:
                recommendations.append({
                    'category': 'AI Overview Optimization',
                    'priority': 'High',
                    'title': 'Add Author Information',
                    'description': 'Include author bylines and bio information to establish content credibility for AI systems.',
                    'impact': 'High',
                    'difficulty': 'Easy'
                })
        
        # GEO recommendations
        if geo_analysis['score'] < 80:
            if not geo_analysis['factors']['citation_quality']:
                recommendations.append({
                    'category': 'Generative Engine Optimization',
                    'priority': 'High',
                    'title': 'Add Quality Citations',
                    'description': 'Include links to authoritative sources (.edu, .gov, .org) to support your claims and build trust.',
                    'impact': 'High',
                    'difficulty': 'Medium'
                })
            
            if not geo_analysis['factors']['content_freshness']:
                recommendations.append({
                    'category': 'Generative Engine Optimization',
                    'priority': 'Medium',
                    'title': 'Update Content Dates',
                    'description': 'Add publication and last updated dates to show content freshness and accuracy.',
                    'impact': 'Medium',
                    'difficulty': 'Easy'
                })
        
        # AEO recommendations
        if aeo_analysis['score'] < 80:
            if not aeo_analysis['factors']['faq_present']:
                recommendations.append({
                    'category': 'Answer Engine Optimization',
                    'priority': 'High',
                    'title': 'Create FAQ Section',
                    'description': 'Add a frequently asked questions section with direct, concise answers to common queries.',
                    'impact': 'High',
                    'difficulty': 'Medium'
                })
            
            if not aeo_analysis['factors']['question_headings']:
                recommendations.append({
                    'category': 'Answer Engine Optimization',
                    'priority': 'Medium',
                    'title': 'Use Question-Based Headings',
                    'description': 'Format some headings as questions (H2, H3) to match user search queries.',
                    'impact': 'Medium',
                    'difficulty': 'Easy'
                })
        
        # Sort recommendations by priority
        priority_order = {'Critical': 0, 'High': 1, 'Medium': 2, 'Low': 3}
        recommendations.sort(key=lambda x: priority_order.get(x['priority'], 3))
        
        return recommendations[:10]  # Return top 10 recommendations
    
    def _create_error_response(self, error_message):
        """Create standardized error response"""
        return {
            'success': False,
            'error': error_message,
            'scores': {
                'master_score': 0,
                'seo_score': 0,
                'aio_score': 0,
                'geo_score': 0,
                'aeo_score': 0,
                'citation_probability': 0
            },
            'recommendations': []
        }

