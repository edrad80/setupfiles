import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Separator } from '@/components/ui/separator.jsx'
import { 
  Search, 
  Zap, 
  FileText, 
  Download, 
  CheckCircle, 
  Star,
  Globe,
  BarChart3,
  Shield,
  Sparkles,
  ArrowRight,
  Brain,
  Target,
  TrendingUp,
  User,
  MessageSquare
} from 'lucide-react'
import Login from './components/Login.jsx'
import Register from './components/Register.jsx'
import Dashboard from './components/Dashboard.jsx'
import ComprehensiveReport from './components/ComprehensiveReport.jsx'
import './App.css'

function App() {
  const [currentView, setCurrentView] = useState('home') // 'home', 'login', 'register', 'dashboard', 'report'
  const [user, setUser] = useState(null)
  const [url, setUrl] = useState('')
  const [isScanning, setIsScanning] = useState(false)
  const [scanResult, setScanResult] = useState(null)

  useEffect(() => {
    // Check if user is already logged in
    const savedUser = localStorage.getItem('user')
    const token = localStorage.getItem('token')
    
    if (savedUser && token) {
      setUser(JSON.parse(savedUser))
      setCurrentView('dashboard')
    }
  }, [])

  const handleLogin = (userData) => {
    setUser(userData)
    setCurrentView('dashboard')
  }

  const handleRegister = (userData) => {
    setUser(userData)
    setCurrentView('dashboard')
  }

  const handleLogout = () => {
    setUser(null)
    setCurrentView('home')
  }

  const handleScan = async () => {
    if (!url) return
    setIsScanning(true)
    
    try {
      const response = await fetch('http://localhost:5000/api/scan', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          url: url,
          email: user?.email // Include user email if logged in
        })
      })
      
      if (response.ok) {
        const result = await response.json()
        setIsScanning(false)
        setScanResult(result)
        setCurrentView('report')
        setUrl('')
      } else {
        const error = await response.json()
        setIsScanning(false)
        alert(`Scan failed: ${error.error}`)
      }
    } catch (err) {
      setIsScanning(false)
      alert('Network error. Please try again.')
    }
  }

  // Render different views based on current state
  if (currentView === 'login') {
    return (
      <Login 
        onLogin={handleLogin}
        onSwitchToRegister={() => setCurrentView('register')}
        onBackToHome={() => setCurrentView('home')}
      />
    )
  }

  if (currentView === 'register') {
    return (
      <Register 
        onRegister={handleRegister}
        onSwitchToLogin={() => setCurrentView('login')}
        onBackToHome={() => setCurrentView('home')}
      />
    )
  }

  if (currentView === 'dashboard' && user) {
    return (
      <Dashboard 
        user={user}
        onLogout={handleLogout}
        onNewScan={() => setCurrentView('home')}
      />
    )
  }

  if (currentView === 'report' && scanResult) {
    return (
      <ComprehensiveReport 
        scanData={scanResult}
        onBack={() => setCurrentView('home')}
      />
    )
  }

  // Home/Landing page
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-blue-600">🤖 AI Optimizer</h1>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="#features" className="text-gray-700 hover:text-blue-600 transition-colors">Features</a>
              <a href="#pricing" className="text-gray-700 hover:text-blue-600 transition-colors">Pricing</a>
              <a href="#how-it-works" className="text-gray-700 hover:text-blue-600 transition-colors">How it Works</a>
            </div>
            <div className="flex items-center space-x-4">
              {user ? (
                <div className="flex items-center space-x-3">
                  <span className="text-sm text-gray-700">Welcome, {user.name}</span>
                  <Button 
                    variant="outline"
                    onClick={() => setCurrentView('dashboard')}
                  >
                    <User className="w-4 h-4 mr-2" />
                    Dashboard
                  </Button>
                </div>
              ) : (
                <Button 
                  variant="outline"
                  onClick={() => setCurrentView('login')}
                >
                  Sign In
                </Button>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16">
          <div className="text-center">
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-blue-100 text-blue-800 text-sm font-medium mb-8">
              <Sparkles className="w-4 h-4 mr-2" />
              AI-Powered Website Optimization
            </div>
            
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
              Optimize Your Website for{' '}
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                AI Search
              </span>
            </h1>
            
            <p className="text-xl text-gray-600 mb-12 max-w-3xl mx-auto">
              Get comprehensive analysis across SEO, AI Overview Optimization, Trust Signals, and Answer Engine Optimization. 
              Improve your visibility in AI-powered search engines like ChatGPT, Perplexity, and Google's AI Overviews.
            </p>

            {/* Scan Input */}
            <div className="max-w-2xl mx-auto mb-8">
              <div className="flex flex-col sm:flex-row gap-4 p-2 bg-white rounded-2xl shadow-lg border border-gray-200">
                <div className="flex-1 relative">
                  <Globe className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <Input
                    type="url"
                    placeholder="Enter your website URL (e.g., https://example.com)"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    className="pl-12 border-0 focus:ring-0 text-lg h-14"
                  />
                </div>
                <Button
                  onClick={handleScan}
                  disabled={isScanning || !url}
                  className="h-14 px-8 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold rounded-xl"
                >
                  {isScanning ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Scanning...
                    </>
                  ) : (
                    <>
                      <Search className="w-5 h-5 mr-2" />
                      Start Free Scan
                    </>
                  )}
                </Button>
              </div>
              
              <div className="flex items-center justify-center mt-4 text-sm text-gray-600">
                <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                First scan is completely free • No signup required
              </div>
            </div>

            {/* Trust Indicators */}
            <div className="flex items-center justify-center space-x-8 text-sm text-gray-500">
              <div className="flex items-center">
                <Star className="w-4 h-4 text-yellow-500 mr-1" />
                Trusted by 1000+ websites
              </div>
              <div className="flex items-center">
                <Shield className="w-4 h-4 text-green-500 mr-1" />
                Secure & Private
              </div>
              <div className="flex items-center">
                <Zap className="w-4 h-4 text-blue-500 mr-1" />
                Instant Results
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Comprehensive AI Optimization Analysis
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our advanced AI analyzes your website across multiple dimensions to ensure maximum 
              visibility in AI-powered search results.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Search,
                title: "SEO Foundation Analysis",
                description: "Technical SEO, content optimization, and performance factors for search visibility"
              },
              {
                icon: Brain,
                title: "AI Overview Optimization",
                description: "Schema markup, E-E-A-T signals, and content structure for AI systems"
              },
              {
                icon: Shield,
                title: "Trust & Authority Signals",
                description: "Credibility indicators, citations, and expertise markers for AI trust"
              },
              {
                icon: MessageSquare,
                title: "Answer Engine Optimization",
                description: "Question-answer format, voice search, and featured snippet optimization"
              },
              {
                icon: TrendingUp,
                title: "Citation Probability Score",
                description: "AI-powered prediction of your content's likelihood to be cited by AI systems"
              },
              {
                icon: Download,
                title: "Comprehensive Reports",
                description: "Detailed HTML reports with downloadable PDF versions and actionable insights"
              }
            ].map((feature, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardHeader>
                  <feature.icon className="w-12 h-12 text-blue-600 mb-4" />
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Simple, Transparent Pricing
            </h2>
            <p className="text-xl text-gray-600">
              Choose the plan that works best for your needs
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {/* Free Plan */}
            <Card className="border-2 border-gray-200">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">Free Scan</CardTitle>
                <div className="text-4xl font-bold text-gray-900 mt-4">£0</div>
                <CardDescription>Perfect for trying out our service</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <ul className="space-y-3">
                  <li className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                    1 website scan
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                    Basic AI optimization report
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                    HTML report view
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                    PDF download
                  </li>
                </ul>
                <Button className="w-full mt-6" variant="outline">
                  Start Free Scan
                </Button>
              </CardContent>
            </Card>

            {/* Single Scan */}
            <Card className="border-2 border-gray-200">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">Single Scan</CardTitle>
                <div className="text-4xl font-bold text-gray-900 mt-4">$2.49</div>
                <CardDescription>For occasional website analysis</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <ul className="space-y-3">
                  <li className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                    1 comprehensive scan
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                    Detailed AI optimization report
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                    Priority recommendations
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                    PDF download
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                    Email support
                  </li>
                </ul>
                <Button className="w-full mt-6" variant="outline">
                  Buy Single Scan
                </Button>
              </CardContent>
            </Card>

            {/* Monthly Plan */}
            <Card className="border-2 border-blue-500 relative">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                <Badge className="bg-blue-500 text-white px-4 py-1">Most Popular</Badge>
              </div>
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">Monthly Unlimited</CardTitle>
                <div className="text-4xl font-bold text-gray-900 mt-4">$19</div>
                <CardDescription>For agencies and active websites</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <ul className="space-y-3">
                  <li className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                    Unlimited website scans
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                    Advanced AI optimization reports
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                    Competitor analysis
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                    Priority support
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                    API access
                  </li>
                </ul>
                <Button className="w-full mt-6 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                  Start Monthly Plan
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section id="how-it-works" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">How It Works</h2>
            <p className="text-xl text-gray-600">
              Get your AI optimization report in just 3 simple steps
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              {
                step: "1",
                title: "Enter Your URL",
                description: "Simply paste your website URL into our scanner. No signup required for your first scan."
              },
              {
                step: "2", 
                title: "AI Analysis",
                description: "Our AI analyzes your website for optimization opportunities across multiple ranking factors."
              },
              {
                step: "3",
                title: "Get Your Report", 
                description: "Receive a detailed report with actionable recommendations and download as PDF."
              }
            ].map((step, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-6">
                  {step.step}
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">{step.title}</h3>
                <p className="text-gray-600 text-lg">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Optimize for AI Search?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Join thousands of websites already optimizing for the future of search. Start with a free scan today.
          </p>
          <Button 
            size="lg"
            className="bg-white text-blue-600 hover:bg-gray-100 text-lg px-8 py-4"
          >
            Start Your Free Scan Now
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </section>
    </div>
  )
}

export default App

