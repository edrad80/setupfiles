import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Separator } from '@/components/ui/separator.jsx'
import { 
  ArrowLeft,
  Download,
  ExternalLink,
  TrendingUp,
  Brain,
  Shield,
  MessageSquare,
  Search,
  AlertTriangle,
  CheckCircle,
  Clock,
  Target,
  Zap,
  Globe,
  BarChart3,
  FileText,
  Star,
  Award,
  Lightbulb
} from 'lucide-react'

const ComprehensiveReport = ({ scanData, onBack }) => {
  const [activeTab, setActiveTab] = useState('overview')

  if (!scanData) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading comprehensive analysis...</p>
        </div>
      </div>
    )
  }

  const { comprehensive_analysis, optimization_breakdown } = scanData
  const scores = comprehensive_analysis?.scores || {}
  const recommendations = comprehensive_analysis?.recommendations || []
  const detailedAnalysis = comprehensive_analysis?.detailed_analysis || {}

  // Get priority color
  const getPriorityColor = (priority) => {
    switch (priority?.toLowerCase()) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200'
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200'
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'low': return 'bg-green-100 text-green-800 border-green-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  // Get score color
  const getScoreColor = (score) => {
    if (score >= 80) return 'text-green-600'
    if (score >= 60) return 'text-yellow-600'
    if (score >= 40) return 'text-orange-600'
    return 'text-red-600'
  }

  // Get score background color
  const getScoreBgColor = (score) => {
    if (score >= 80) return 'bg-green-50 border-green-200'
    if (score >= 60) return 'bg-yellow-50 border-yellow-200'
    if (score >= 40) return 'bg-orange-50 border-orange-200'
    return 'bg-red-50 border-red-200'
  }

  const optimizationAreas = [
    {
      key: 'seo',
      title: 'SEO Foundation',
      description: 'Technical SEO, content optimization, and performance factors',
      icon: Search,
      score: optimization_breakdown?.seo_score || 0,
      details: detailedAnalysis.seo
    },
    {
      key: 'aio',
      title: 'AI Overview Optimization',
      description: 'Schema markup, E-E-A-T signals, and AI-friendly content structure',
      icon: Brain,
      score: optimization_breakdown?.aio_score || 0,
      details: detailedAnalysis.aio
    },
    {
      key: 'geo',
      title: 'Generative Engine Optimization',
      description: 'Authority signals, credibility indicators, and trust factors',
      icon: Shield,
      score: optimization_breakdown?.geo_score || 0,
      details: detailedAnalysis.geo
    },
    {
      key: 'aeo',
      title: 'Answer Engine Optimization',
      description: 'Question-answer format, voice search, and featured snippets',
      icon: MessageSquare,
      score: optimization_breakdown?.aeo_score || 0,
      details: detailedAnalysis.aeo
    }
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={onBack}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">AI Optimization Report</h1>
                <p className="text-sm text-gray-600">{scanData.url}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="outline">
                <Download className="w-4 h-4 mr-2" />
                Download PDF
              </Button>
              <Button variant="outline">
                <ExternalLink className="w-4 h-4 mr-2" />
                Share Report
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex space-x-8">
            {[
              { id: 'overview', label: 'Overview', icon: BarChart3 },
              { id: 'seo', label: 'SEO Foundation', icon: Search },
              { id: 'aio', label: 'AI Overview', icon: Brain },
              { id: 'geo', label: 'Trust Signals', icon: Shield },
              { id: 'aeo', label: 'Answer Format', icon: MessageSquare },
              { id: 'recommendations', label: 'Recommendations', icon: Lightbulb }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center px-1 py-4 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <tab.icon className="w-4 h-4 mr-2" />
                {tab.label}
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'overview' && (
          <div className="space-y-8">
            {/* Master Score Card */}
            <Card className={`border-2 ${getScoreBgColor(scores.master_score)}`}>
              <CardHeader className="text-center">
                <div className="flex items-center justify-center mb-4">
                  <div className={`text-6xl font-bold ${getScoreColor(scores.master_score)}`}>
                    {scores.master_score || 0}
                  </div>
                  <div className="text-2xl text-gray-500 ml-2">/100</div>
                </div>
                <CardTitle className="text-2xl">AI Optimization Score</CardTitle>
                <CardDescription className="text-lg">
                  Your website's overall readiness for AI-powered search engines
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Citation Probability</span>
                      <span className="text-sm font-bold">{scores.citation_probability || 0}%</span>
                    </div>
                    <Progress value={scores.citation_probability || 0} className="h-2" />
                    <p className="text-xs text-gray-600">
                      Likelihood of being cited by AI systems like ChatGPT and Perplexity
                    </p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Overall Performance</span>
                      <Badge variant="outline" className={getScoreColor(scores.master_score)}>
                        {scores.master_score >= 80 ? 'Excellent' : 
                         scores.master_score >= 60 ? 'Good' : 
                         scores.master_score >= 40 ? 'Fair' : 'Needs Improvement'}
                      </Badge>
                    </div>
                    <p className="text-xs text-gray-600">
                      Based on comprehensive analysis across SEO, AIO, GEO, and AEO factors
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Optimization Areas Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {optimizationAreas.map((area) => (
                <Card 
                  key={area.key} 
                  className={`cursor-pointer transition-all hover:shadow-lg ${getScoreBgColor(area.score)}`}
                  onClick={() => setActiveTab(area.key)}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <area.icon className={`w-8 h-8 ${getScoreColor(area.score)}`} />
                      <div className={`text-2xl font-bold ${getScoreColor(area.score)}`}>
                        {area.score}
                      </div>
                    </div>
                    <CardTitle className="text-lg">{area.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Progress value={area.score} className="mb-3 h-2" />
                    <p className="text-sm text-gray-600">{area.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Quick Insights */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Top Issues */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <AlertTriangle className="w-5 h-5 mr-2 text-red-500" />
                    Critical Issues
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {recommendations
                      .filter(rec => rec.priority === 'Critical')
                      .slice(0, 3)
                      .map((rec, index) => (
                        <div key={index} className="flex items-start space-x-3 p-3 bg-red-50 rounded-lg">
                          <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5" />
                          <div>
                            <p className="font-medium text-sm">{rec.title}</p>
                            <p className="text-xs text-gray-600">{rec.description}</p>
                          </div>
                        </div>
                      ))}
                    {recommendations.filter(rec => rec.priority === 'Critical').length === 0 && (
                      <div className="flex items-center space-x-2 text-green-600">
                        <CheckCircle className="w-4 h-4" />
                        <span className="text-sm">No critical issues found!</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Quick Wins */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Zap className="w-5 h-5 mr-2 text-green-500" />
                    Quick Wins
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {recommendations
                      .filter(rec => rec.difficulty === 'Easy' && rec.impact === 'High')
                      .slice(0, 3)
                      .map((rec, index) => (
                        <div key={index} className="flex items-start space-x-3 p-3 bg-green-50 rounded-lg">
                          <Zap className="w-4 h-4 text-green-500 mt-0.5" />
                          <div>
                            <p className="font-medium text-sm">{rec.title}</p>
                            <p className="text-xs text-gray-600">{rec.description}</p>
                          </div>
                        </div>
                      ))}
                    {recommendations.filter(rec => rec.difficulty === 'Easy' && rec.impact === 'High').length === 0 && (
                      <div className="text-sm text-gray-600">
                        Check the recommendations tab for optimization opportunities.
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {/* Individual Optimization Area Tabs */}
        {optimizationAreas.map((area) => (
          activeTab === area.key && (
            <div key={area.key} className="space-y-6">
              {/* Area Header */}
              <Card className={getScoreBgColor(area.score)}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <area.icon className={`w-12 h-12 ${getScoreColor(area.score)}`} />
                      <div>
                        <CardTitle className="text-2xl">{area.title}</CardTitle>
                        <CardDescription className="text-lg">{area.description}</CardDescription>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`text-4xl font-bold ${getScoreColor(area.score)}`}>
                        {area.score}
                      </div>
                      <div className="text-sm text-gray-500">out of 100</div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Progress value={area.score} className="h-3" />
                </CardContent>
              </Card>

              {/* Detailed Analysis */}
              {area.details && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Component Scores */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Component Analysis</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {Object.entries(area.details)
                        .filter(([key]) => key.includes('_score'))
                        .map(([key, value]) => (
                          <div key={key} className="space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="text-sm font-medium capitalize">
                                {key.replace('_score', '').replace('_', ' ')}
                              </span>
                              <span className={`text-sm font-bold ${getScoreColor(value)}`}>
                                {value}/100
                              </span>
                            </div>
                            <Progress value={value} className="h-2" />
                          </div>
                        ))}
                    </CardContent>
                  </Card>

                  {/* Factors Analysis */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Key Factors</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {area.details.factors && Object.entries(area.details.factors).map(([factor, status]) => (
                          <div key={factor} className="flex items-center justify-between">
                            <span className="text-sm capitalize">
                              {factor.replace(/_/g, ' ')}
                            </span>
                            {status ? (
                              <CheckCircle className="w-4 h-4 text-green-500" />
                            ) : (
                              <AlertTriangle className="w-4 h-4 text-red-500" />
                            )}
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* Area-specific Recommendations */}
              <Card>
                <CardHeader>
                  <CardTitle>Recommendations for {area.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recommendations
                      .filter(rec => rec.category.toLowerCase().includes(area.key) || 
                                   rec.category.toLowerCase().includes(area.title.toLowerCase().split(' ')[0]))
                      .map((rec, index) => (
                        <div key={index} className="border rounded-lg p-4">
                          <div className="flex items-start justify-between mb-2">
                            <h4 className="font-medium">{rec.title}</h4>
                            <div className="flex space-x-2">
                              <Badge variant="outline" className={getPriorityColor(rec.priority)}>
                                {rec.priority}
                              </Badge>
                              {rec.impact && (
                                <Badge variant="outline">
                                  {rec.impact} Impact
                                </Badge>
                              )}
                            </div>
                          </div>
                          <p className="text-sm text-gray-600 mb-2">{rec.description}</p>
                          {rec.difficulty && (
                            <div className="text-xs text-gray-500">
                              Difficulty: {rec.difficulty}
                            </div>
                          )}
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )
        ))}

        {/* Recommendations Tab */}
        {activeTab === 'recommendations' && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Lightbulb className="w-6 h-6 mr-2 text-yellow-500" />
                  All Recommendations
                </CardTitle>
                <CardDescription>
                  Prioritized action items to improve your AI optimization score
                </CardDescription>
              </CardHeader>
            </Card>

            {/* Recommendations by Priority */}
            {['Critical', 'High', 'Medium', 'Low'].map((priority) => {
              const priorityRecs = recommendations.filter(rec => rec.priority === priority)
              if (priorityRecs.length === 0) return null

              return (
                <Card key={priority}>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Badge className={getPriorityColor(priority)} variant="outline">
                        {priority} Priority
                      </Badge>
                      <span className="ml-3">{priorityRecs.length} items</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {priorityRecs.map((rec, index) => (
                        <div key={index} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex-1">
                              <h4 className="font-medium text-lg mb-1">{rec.title}</h4>
                              <p className="text-gray-600 mb-2">{rec.description}</p>
                              <div className="flex items-center space-x-4 text-sm text-gray-500">
                                <span>Category: {rec.category}</span>
                                {rec.impact && <span>Impact: {rec.impact}</span>}
                                {rec.difficulty && <span>Difficulty: {rec.difficulty}</span>}
                              </div>
                            </div>
                            <div className="flex flex-col space-y-2 ml-4">
                              <Badge variant="outline" className={getPriorityColor(rec.priority)}>
                                {rec.priority}
                              </Badge>
                              {rec.impact && (
                                <Badge variant="outline">
                                  {rec.impact}
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

export default ComprehensiveReport

