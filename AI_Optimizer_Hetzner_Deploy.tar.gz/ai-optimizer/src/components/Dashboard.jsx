import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Separator } from '@/components/ui/separator.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { 
  LogOut, 
  User, 
  FileText, 
  Download, 
  Calendar,
  TrendingUp,
  BarChart3,
  Globe,
  Plus,
  Eye,
  Crown,
  Zap
} from 'lucide-react'

export default function Dashboard({ user, onLogout, onNewScan }) {
  const [scans, setScans] = useState([])
  const [subscription, setSubscription] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    fetchUserData()
  }, [])

  const fetchUserData = async () => {
    try {
      const token = localStorage.getItem('token')
      
      // Fetch user's scans
      const scansResponse = await fetch(`https://77h9ikcwemz9.manus.space/api/user-scans/${user.email}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      
      if (scansResponse.ok) {
        const scansData = await scansResponse.json()
        setScans(scansData.scans || [])
      }

      // Fetch subscription status
      const subResponse = await fetch(`https://77h9ikcwemz9.manus.space/api/subscription-status/${user.email}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      
      if (subResponse.ok) {
        const subData = await subResponse.json()
        setSubscription(subData.subscription)
      }

    } catch (err) {
      setError('Failed to load dashboard data')
    } finally {
      setIsLoading(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem('user')
    localStorage.removeItem('token')
    onLogout()
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const getScoreColor = (score) => {
    if (score >= 80) return 'text-green-600'
    if (score >= 60) return 'text-yellow-600'
    return 'text-red-600'
  }

  const getScoreBadgeVariant = (score) => {
    if (score >= 80) return 'default'
    if (score >= 60) return 'secondary'
    return 'destructive'
  }

  const getPlanBadge = () => {
    if (!subscription) return { text: 'Free', variant: 'secondary', icon: null }
    
    switch (subscription.plan_type) {
      case 'monthly':
        return { text: 'Pro', variant: 'default', icon: Crown }
      case 'single':
        return { text: 'Single', variant: 'outline', icon: Zap }
      default:
        return { text: 'Free', variant: 'secondary', icon: null }
    }
  }

  const planBadge = getPlanBadge()

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-blue-600">🤖 AI Optimizer</h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <User className="w-4 h-4 text-gray-500" />
                <span className="text-sm text-gray-700">{user.name}</span>
                {planBadge.icon && <planBadge.icon className="w-4 h-4 text-yellow-500" />}
                <Badge variant={planBadge.variant}>{planBadge.text}</Badge>
              </div>
              <Button variant="outline" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Welcome back, {user.name}!</h2>
          <p className="text-gray-600">Manage your website scans and view optimization reports.</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Scans</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{scans.length}</div>
              <p className="text-xs text-muted-foreground">
                Websites analyzed
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Average Score</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {scans.length > 0 
                  ? Math.round(scans.reduce((sum, scan) => sum + scan.score, 0) / scans.length)
                  : 0
                }/100
              </div>
              <p className="text-xs text-muted-foreground">
                AI optimization score
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Plan Status</CardTitle>
              {planBadge.icon && <planBadge.icon className="h-4 w-4 text-yellow-500" />}
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{planBadge.text}</div>
              <p className="text-xs text-muted-foreground">
                {subscription?.plan_type === 'monthly' 
                  ? 'Unlimited scans' 
                  : subscription?.plan_type === 'single'
                  ? `${subscription.scans_limit - subscription.scans_used} scans left`
                  : '1 free scan available'
                }
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <Button 
            onClick={onNewScan}
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Scan
          </Button>
          <Button variant="outline">
            <Crown className="w-4 h-4 mr-2" />
            Upgrade Plan
          </Button>
        </div>

        {/* Recent Scans */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="w-5 h-5 mr-2" />
              Recent Scans
            </CardTitle>
            <CardDescription>
              View and download your website optimization reports
            </CardDescription>
          </CardHeader>
          <CardContent>
            {scans.length === 0 ? (
              <div className="text-center py-8">
                <Globe className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No scans yet</h3>
                <p className="text-gray-600 mb-4">Start by scanning your first website to see optimization recommendations.</p>
                <Button onClick={onNewScan}>
                  <Plus className="w-4 h-4 mr-2" />
                  Scan Your First Website
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {scans.map((scan) => (
                  <div key={scan.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3">
                        <Globe className="w-5 h-5 text-gray-400" />
                        <div>
                          <h4 className="font-medium text-gray-900">{scan.url}</h4>
                          <p className="text-sm text-gray-600">
                            Scanned on {formatDate(scan.scan_date)}
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <Badge variant={getScoreBadgeVariant(scan.score)}>
                          {scan.score}/100
                        </Badge>
                        <p className="text-xs text-gray-500 mt-1">AI Score</p>
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => window.open(`https://77h9ikcwemz9.manus.space/api/report/${scan.id}`, '_blank')}
                        >
                          <Eye className="w-4 h-4 mr-1" />
                          View
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => window.open(`https://77h9ikcwemz9.manus.space/api/report/${scan.id}/download`, '_blank')}
                        >
                          <Download className="w-4 h-4 mr-1" />
                          Download
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

